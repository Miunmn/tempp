//
// Created by esteb on 6/12/2020.
//

#ifndef FILES_MACROS_H
#define FILES_MACROS_H

#define DEBUG 1

#endif //FILES_MACROS_H
