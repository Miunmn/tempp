#pragma once

#include "Geometry.h"
#include "Directory.h"


namespace Battleship 
{
	
}