#pragma once

namespace Directory {}

namespace Geometry {}

namespace Battleship {}